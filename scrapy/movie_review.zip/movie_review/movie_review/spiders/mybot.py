import scrapy
from movie_review.items import MovieReviewItem
import sys


class MybotSpider(scrapy.Spider):
    name = 'mybot'
    allowed_domains = ['naver.com']
    start_urls = ['http://movie.naver.com/movie/point/af/list.nhn']

    def parse(self, response):
        titles = response.xpath(
            '//*[@id="old_content"]/table/tbody/tr/td[2]/a[1]/text()').extract()
        scores = response.xpath(
            '//*[@id="old_content"]/table/tbody/tr/td[2]/div/em/text()').extract()
        contents = response.xpath(
            '//*[@id="old_content"]/table/tbody/tr/td[2]/text()').extract()
        authors = response.css('.author::text').extract()
        dates = response.xpath(
            '//*[@id="old_content"]/table/tbody/tr/td[3]/text()').extract()

        items = []
        for idx in range(len(titles)):
            item = MovieReviewItem()
            item['title'] = titles[idx]
            item['score'] = scores[idx]
            item['content'] = contents[idx].strip()
            item['author'] = authors[idx]
            item['date'] = dates[idx]

            items.append(item)

        return items
